// Test Expressions
int test = 1;
int main () {
	int a=1, b=2, c;
	c = a + b;
	c = a- b;
	a++;
	a--;
	a = a + 1;
	a = a>>2;
	b = a / b;
	double d;
	d = a+d;
	a = b > a ? b : a;
	int check = a+b*c;
	if (check < c) 
		c = a|b;
	i = ++a + b++;
}
